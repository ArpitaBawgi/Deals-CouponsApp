package com.project.OnCallDoctorUsers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnCallDoctorUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
