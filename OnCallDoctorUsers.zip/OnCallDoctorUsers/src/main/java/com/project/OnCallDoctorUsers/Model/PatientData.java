package com.project.OnCallDoctorUsers.Model;

import java.sql.Time;
import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="PatientData")
public class PatientData {

	@Id
	private String patientId;
	private String fullName;
	private String gender;
	private long phoneNumber;
	private Integer age;
	private String email;
	private boolean lastpresence;
	private String presenceDetails;
	private LocalDateTime scheduleDateTime;
	
	PatientData(){
	}


	public PatientData(String patientId, String fullName, String gender, long phoneNumber, Integer age, String email,
			boolean lastpresence, String presenceDetails, LocalDateTime scheduleDateTime) {
		super();
		this.patientId = patientId;
		this.fullName = fullName;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.email = email;
		this.lastpresence = lastpresence;
		this.presenceDetails = presenceDetails;
		this.scheduleDateTime = scheduleDateTime;
	}



	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPatientId() {
		return patientId;
	}


	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}


	public Integer getAge() {
		return age;
	}


	public void setAge(Integer age) {
		this.age = age;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public LocalDateTime getScheduleDateTime() {
		return scheduleDateTime;
	}


	public void setScheduleDateTime(LocalDateTime scheduleDateTime) {
		this.scheduleDateTime = scheduleDateTime;
	}


	public boolean isLastpresence() {
		return lastpresence;
	}

	public void setLastpresence(boolean lastpresence) {
		this.lastpresence = lastpresence;
	}

	public String getPresenceDetails() {
		return presenceDetails;
	}

	public void setPresenceDetails(String presenceDetails) {
		this.presenceDetails = presenceDetails;
	}


	@Override
	public String toString() {
		return "PatientData [patientId=" + patientId + ", fullName=" + fullName + ", gender=" + gender
				+ ", phoneNumber=" + phoneNumber + ", age=" + age + ", email=" + email + ", lastpresence="
				+ lastpresence + ", presenceDetails=" + presenceDetails + ", scheduleDateTime=" + scheduleDateTime
				+ "]";
	}
}
