package com.project.OnCallDoctorUsers.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="CustomerData")
public class Customer {

	@Id
	private String CustomerId;
	
	private String fname;
	
	private String lname;
	
	private long mobilenumber;
	
	private String email;
	
	private String password;
	
	private PatientData patientData;
	
	Customer(){
	}	
	
	public Customer(String customerId, String fname, String lname, long mobilenumber, String email, String password,
			PatientData patientData) {
		super();
		CustomerId = customerId;
		this.fname = fname;
		this.lname = lname;
		this.mobilenumber = mobilenumber;
		this.email = email;
		this.password = password;
		this.patientData = patientData;
	}

	public String getCustomerId() {
		return CustomerId;
	}

	public void setCustomerId(String customerId) {
		CustomerId = customerId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public long getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

//	@Override
//	public String toString() {
//		return "Customer [CustomerId=" + CustomerId + ", fname=" + fname + ", lname=" + lname + ", mobilenumber="
//				+ mobilenumber + ", email=" + email + ", password=" + password + ", patientData=" + patientData
//				+ "]";
//	}
	
	
	
}
