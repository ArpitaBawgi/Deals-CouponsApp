package com.project.OnCallDoctorUsers.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.OnCallDoctorUsers.Service.CustomerService;
import com.project.OnCallDoctorUsers.Service.Impl.CustomerServiceImpl;
import com.project.OnCallDoctorUsers.Model.Customer;
import com.project.OnCallDoctorUsers.Model.PatientData;
import com.project.OnCallDoctorUsers.Model.Payment;
import com.project.OnCallDoctorUsers.Repository.CustomerRepo;

@CrossOrigin(origins="http://localhost:4200", allowedHeaders={"x-auth-token", "x-requested-with", "x-xsrf-token"})
@RestController
public class CustomerController {
	
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private CustomerRepo custRepo;
	
	@Autowired
	private CustomerService custService;
	
	
	private String email="";
	
	@PostMapping("/customer/register")
	public ResponseEntity<Customer> RegistrationOfCustomer(@RequestBody Customer customer){
		System.out.println(customer.getEmail());
		
		Customer custFind=custRepo.findByEmail(customer.getEmail());
		if(custFind != null) {
			return new ResponseEntity<Customer>(HttpStatus.CONFLICT);
		}
		
		Customer status=custService.AddCustomerDetails(customer);
		return new ResponseEntity<Customer>(status, HttpStatus.CREATED);
	}
	
	
	@GetMapping("/customer/allcustomer")
	public ResponseEntity<List<Customer>> getAllCustomers(){
		List<Customer> cust=new ArrayList<>();
		try {
			custRepo.findAll().forEach(cust::add);
		
			if(cust.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(cust, HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR );
		}
	}
	
	//@GetMapping("/customer/{emailid}/{password}")
	@PostMapping("/customer/signin")
	public ResponseEntity<Customer> LoginofCustomer(@RequestBody Customer customer){
		Customer cust=custService.findByEmail(customer.getEmail());
	
		if(cust==null) {
			return new ResponseEntity<Customer>(cust,HttpStatus.NOT_FOUND);
		}
		
		if((cust.getEmail().equals(customer.getEmail()) && (cust.getPassword().equals(customer.getPassword())))){
			this.email=email;
			//to check
			
			System.out.println(this.email);
			
			return new ResponseEntity<Customer>(cust,HttpStatus.OK);
		}
		return new ResponseEntity<Customer>(HttpStatus.UNAUTHORIZED);
	}
	
	@GetMapping("/customer/totalCustomercount")
	public long totalCount() {
		return custRepo.count();
	}
	
	
	@PostMapping("/customer/patient/savedata")
	public ResponseEntity<PatientData> patientdata(@RequestBody PatientData patientData) throws Exception{
		patientData.setEmail(this.email);
		
		HttpEntity<PatientData> requestEntity= new HttpEntity<PatientData>(patientData);
	    
		PatientData data=restTemplate.exchange("http://PatientService/patient/savedata", HttpMethod.POST, requestEntity, PatientData.class).getBody();
		
		return new ResponseEntity<PatientData>(data, HttpStatus.ACCEPTED);
	
	}
	
	@GetMapping("/customer/patient/mypdata")
	public ResponseEntity<PatientData> patientData() throws Exception{
		PatientData mydata=restTemplate.getForEntity("http://PatientService/patient/mypdata"+this.email, PatientData.class).getBody();
		return new ResponseEntity<PatientData>(mydata, HttpStatus.FOUND); 
				
	}
	
	//for payment controller
	@PostMapping("/customer/payment")
	public ResponseEntity<Payment> payment(@RequestBody Payment payment){
		payment.setEmail(email);
		HttpEntity<Payment> requestEntity = new HttpEntity<Payment>(payment);

		Payment payment1 = restTemplate
				.exchange("http://PaymentService/payment", HttpMethod.POST, requestEntity, Payment.class).getBody();
		return new ResponseEntity<Payment>(payment1, HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/customer/mypayments")
	public ResponseEntity<Payment> myPaymentList() throws Exception{
		Payment mypayments=restTemplate.getForEntity("http://PaymentService/mypayments/"+this.email, Payment.class).getBody();
		return new ResponseEntity<Payment>(mypayments,HttpStatus.OK);
	}

}
