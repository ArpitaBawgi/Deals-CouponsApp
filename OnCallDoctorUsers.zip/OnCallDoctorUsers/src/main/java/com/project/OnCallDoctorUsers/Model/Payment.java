package com.project.OnCallDoctorUsers.Model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="paymentDetails")
public class Payment {

	private String email;
	private CardDetails cardDetails;
	
	public Payment() {
		super();
	}

	public Payment(String email, CardDetails cardDetails) {
		super();
		this.email = email;
		this.cardDetails = cardDetails;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public CardDetails getCardDetails() {
		return cardDetails;
	}

	public void setCardDetails(CardDetails cardDetails) {
		this.cardDetails = cardDetails;
	}
	
	
	
	
}
