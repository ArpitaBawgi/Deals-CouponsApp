package com.project.OnCallDoctorUsers.Service;

import java.util.List;

import com.project.OnCallDoctorUsers.Model.Customer;

public interface CustomerService {

	public Customer findByEmail(String email);
	public Customer AddCustomerDetails(Customer customer);
	public List<Customer> findAllCustomers();
}
