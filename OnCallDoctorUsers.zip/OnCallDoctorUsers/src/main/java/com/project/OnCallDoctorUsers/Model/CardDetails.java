package com.project.OnCallDoctorUsers.Model;

public class CardDetails {

	private Integer cvv;
	private Long cardNumber;
	private String cardHolderName;
	private String cardExpiryMonth;
	private Integer cardExpiryYear;

	public CardDetails() {
		super();
	}

	public CardDetails(Integer cvv, Long cardNumber, String cardHolderName, String cardExpiryMonth,
			Integer cardExpiryYear) {
		super();
		this.cvv = cvv;
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.cardExpiryMonth = cardExpiryMonth;
		this.cardExpiryYear = cardExpiryYear;
	}

	public Integer getCvv() {
		return cvv;
	}

	public void setCvv(Integer cvv) {
		this.cvv = cvv;
	}

	public Long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(Long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public String getCardExpiryMonth() {
		return cardExpiryMonth;
	}

	public void setCardExpiryMonth(String cardExpiryMonth) {
		this.cardExpiryMonth = cardExpiryMonth;
	}

	public Integer getCardExpiryYear() {
		return cardExpiryYear;
	}

	public void setCardExpiryYear(Integer cardExpiryYear) {
		this.cardExpiryYear = cardExpiryYear;
	}

	@Override
	public String toString() {
		return "CardDetails [cvv=" + cvv + ", cardNumber=" + cardNumber + ", cardHolderName=" + cardHolderName
				+ ", cardExpiryMonth=" + cardExpiryMonth + ", cardExpiryYear=" + cardExpiryYear + "]";
	}

}
