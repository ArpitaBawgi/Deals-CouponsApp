package com.project.OnCallDoctorUsers.Service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.project.OnCallDoctorUsers.Model.Customer;
import com.project.OnCallDoctorUsers.Repository.CustomerRepo;
import com.project.OnCallDoctorUsers.Service.CustomerService;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo customerRepo;


	@Override
	public Customer findByEmail(String email) {
		return customerRepo.findByEmail(email);
	}

	@Override
	public Customer AddCustomerDetails(Customer customer) {
		return customerRepo.save(customer);
	}

	@Override
	public List<Customer> findAllCustomers() {
		return customerRepo.findAll();
	}

  


}



