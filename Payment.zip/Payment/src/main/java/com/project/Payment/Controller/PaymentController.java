package com.project.Payment.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.Payment.Model.Payment;
import com.project.Payment.Service.PaymentService;

@CrossOrigin("*")
@RestController
public class PaymentController {

	@Autowired
	private PaymentService paymentService;
	
	@PostMapping("/payment")
	public ResponseEntity<Payment> AddPaymentDetails(@RequestBody Payment payment){
		Payment newPay=paymentService.addPaymentDetails(payment);
	    return new ResponseEntity<Payment>(newPay,HttpStatus.CREATED);
	}
	
	@GetMapping("/mypayments/{email}")
	public ResponseEntity<Payment> myPaymentList(@PathVariable String email){
		
		Payment status=paymentService.findByEmail(email);
		if(status == null) {
			return new ResponseEntity<Payment>(HttpStatus.NO_CONTENT); 
		}
		
		return new ResponseEntity<Payment>(status,HttpStatus.OK);
	}
	
	
}
