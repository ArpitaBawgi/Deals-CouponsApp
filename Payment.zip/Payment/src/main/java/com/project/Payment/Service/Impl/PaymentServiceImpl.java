package com.project.Payment.Service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.Payment.Model.Payment;
import com.project.Payment.Model.Repository.PaymentRepository;
import com.project.Payment.Service.PaymentService;

public class PaymentServiceImpl implements PaymentService {
	
	
	@Autowired
	private PaymentRepository payRepo;

	@Override
	public Payment findByEmail(String payment) {
		return payRepo.findByEmail(payment);
	}

	@Override
	public Payment addPaymentDetails(Payment payment) {
		return payRepo.save(payment);
	}

	@Override
	public List<Payment> findAllPayments(String email) {
		return payRepo.findAll();
	}

}
