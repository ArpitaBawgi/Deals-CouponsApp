package com.project.Payment.Model.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.project.Payment.Model.Payment;

public interface PaymentRepository extends MongoRepository<Payment, String>{
	
	public Payment findByEmail(String email);

}
