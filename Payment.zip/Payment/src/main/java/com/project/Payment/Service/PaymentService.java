package com.project.Payment.Service;

import java.util.List;

import com.project.Payment.Model.Payment;

public interface PaymentService {

	public Payment findByEmail(String email);
	
	public Payment addPaymentDetails(Payment payment);
	
	public List<Payment> findAllPayments(String email);
	

//	public Payment updatePayementDetails(Payment payment);
}
