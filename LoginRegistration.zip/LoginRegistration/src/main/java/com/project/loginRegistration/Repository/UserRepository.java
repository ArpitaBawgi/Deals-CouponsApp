package com.project.loginRegistration.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


import com.project.loginRegistration.Models.User;

@Repository
public interface UserRepository extends MongoRepository<User, String> {
	
	public User getByfname(String fname);
    User getByemailid(String emailid);

}
