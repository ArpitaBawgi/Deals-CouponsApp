package com.project.loginRegistration.Models;

public class CardDetails {

	private Integer cvv;
	private long cardNumber;
	private String cardHolderName;
	private String bankName;
	private String cardExpiry;
	
	CardDetails(){
	}

	public CardDetails(Integer cvv, long cardNumber, String cardHolderName, String bankName, String cardExpiry) {
		super();
		this.cvv = cvv;
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.bankName = bankName;
		this.cardExpiry = cardExpiry;
	}

	public Integer getCvv() {
		return cvv;
	}

	public void setCvv(Integer cvv) {
		this.cvv = cvv;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getCardExpiry() {
		return cardExpiry;
	}

	public void setCardExpiry(String cardExpiry) {
		this.cardExpiry = cardExpiry;
	}
	
	
	
	
}
