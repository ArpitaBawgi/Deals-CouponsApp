package com.project.loginRegistration.Service;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;

import com.project.loginRegistration.Models.User;

@Service
public interface UserService{

	public User getByemailid(String emailid);
	public User addUserDetails(User user);
}
