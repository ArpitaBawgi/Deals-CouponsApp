package com.project.loginRegistration.Models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="UserDetails")
public class User {
	

	@Id
	private String userid;
	private String fname;
	private String lname;
	private String mobilenumber;
	private String emailid;
	private String password;
	private Payment payment;
	private Wishlist wishlist;
	
	User(){
	}
	
	public User(String fname, String lname, String mobilenumber, String emailid, String password) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.mobilenumber = mobilenumber;
		this.emailid = emailid;
		this.password = password;
	}


	

	public User(String userid, String fname, String lname, String mobilenumber, String emailid, String password,
			Payment payment) {
		super();
		this.userid = userid;
		this.fname = fname;
		this.lname = lname;
		this.mobilenumber = mobilenumber;
		this.emailid = emailid;
		this.password = password;
		this.payment = payment;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}


	@Override
	public String toString() {
		return "User [userid=" + userid + ", fname=" + fname + ", lname=" + lname + ", mobilenumber=" + mobilenumber
				+ ", emailid=" + emailid + ", password=" + password + "]";
	}
	

}
