package com.project.loginRegistration.Models;

public class Wishlist {

	private Coupons coupon;
	
	Wishlist(){
		super();
	}
	
	public Wishlist(Coupons coupon) {
		super();
		this.coupon=coupon;
	}

	public Coupons getCoupon() {
		return coupon;
	}

	public void setCoupon(Coupons coupon) {
		this.coupon = coupon;
	}


	
}
