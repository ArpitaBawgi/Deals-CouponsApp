package com.project.loginRegistration.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.loginRegistration.Models.User;
import com.project.loginRegistration.Repository.UserRepository;
import com.project.loginRegistration.Service.UserService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class UserController {
 
		
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private RestTemplate restTemplate;

	private String emailid;
	
	@PostMapping("/user/register")
	public ResponseEntity<User> signUpofCustomer(@RequestBody User user){
		User status=userService.addUserDetails(user);
		return new ResponseEntity<User>(status, HttpStatus.CREATED);
	}
	
	@GetMapping("/user/allUsers")
	public ResponseEntity<List<User>> getAllUsers(){
		List<User> user=new ArrayList<>();
		try {
			userRepo.findAll().forEach(user::add);
			
			if(user.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(user,HttpStatus.OK);
		}catch (Exception e){
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/user/{userid}")
	public ResponseEntity<User> getUserById(@PathVariable String userid){
		Optional<User> userdata=userRepo.findById(userid);
		
		if(userdata.isPresent()) {
			return new ResponseEntity<>(userdata.get(), HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/user/signin/")
	//@GetMapping("/user/{emailid}")
	public ResponseEntity<User> loginOfUser(@PathVariable String emailid, @PathVariable String password){
		User user=userService.getByemailid(emailid);
		
		if(user==null) {
			return new ResponseEntity<User>(user, HttpStatus.NOT_FOUND);
		}
		
		if((user.getEmailid().equals(emailid) && (user.getPassword().equals(password)))) {
			this.emailid=emailid;
			System.out.println(this.emailid);
			
			return new ResponseEntity<User>(user, HttpStatus.OK);
		}
		return new ResponseEntity<User>(HttpStatus.UNAUTHORIZED);
	}
	
	@GetMapping("/user/{emaiid}")
	public ResponseEntity<User> findByemailId(@PathVariable("id") String emailid){
		try {
		User user=userService.getByemailid(emailid);
		if(user==null) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(user, HttpStatus.OK);
		}
		catch( Exception e) {
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@DeleteMapping("/user/{id}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id") String emailid){
		try {
			userRepo.deleteById(emailid);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);		}
	}

	
	
//	@PostMapping("/user/create")
//	public String createUser(@RequestBody User user) {
//		userRepo.save(user);
//		return "Created User Successfully!" ;
//	}
//	
//	@RequestMapping(method=RequestMethod.DELETE, value="user/remove")
//	void remove(@RequestBody User user) {
//		userRepo.delete(user);
//	}
//
	@GetMapping("/alluser")
	public List<User> getUsers(){
		return userRepo.findAll();
	}
//	
//	@RequestMapping("user/total")
//	public long total() {
//		return userRepo.count();
//	}
//	
//	@RequestMapping("user/fname/{fname}")
//	public User findByFirstName(@PathVariable String fname) {
//		return userRepo.getByfname(fname);
//	}
//	
//	@PostMapping("/user/createall")
//	void creatAll(@RequestBody ArrayList<User> user) {
//		userRepo.saveAll(user);
//	}
//	
//	@RequestMapping("/user/searchbyid/{id}")
//	public Optional<User> searchById(@PathVariable String id) {
//		return userRepo.findById(id);
//	}
//	
//	@RequestMapping(method = RequestMethod.GET, value = "/user/present/{id}")
//	public boolean isPresent(@PathVariable String id) {
//		return userRepo.existsById(id);
//	}
//	
//
//	
//	@RequestMapping("/user/findbyemail/{emailid}")
//	public User findByemail(@PathVariable String emailid) {
//		return userRepo.getByemailid(emailid);
//	}
	
}
