package com.project.loginRegistration.Models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="paymentList")
public class Payment {
	@Id
	private String emailid;
	private String cashOnDelivery;
	private CardDetails carddetails;
	

	Payment(){
	}


	public Payment(String emailid, String cashOnDelivery, CardDetails carddetails) {
		super();
		this.emailid = emailid;
		this.cashOnDelivery = cashOnDelivery;
		this.carddetails = carddetails;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getCashOnDelivery() {
		return cashOnDelivery;
	}


	public void setCashOnDelivery(String cashOnDelivery) {
		this.cashOnDelivery = cashOnDelivery;
	}


	public CardDetails getCarddetails() {
		return carddetails;
	}


	public void setCarddetails(CardDetails carddetails) {
		this.carddetails = carddetails;
	}


	@Override
	public String toString() {
		return "Payment [emailid=" + emailid + ", cashOnDelivery=" + cashOnDelivery + ", carddetails=" + carddetails
				+ "]";
	}

}
