package com.project.loginRegistration.Service.Impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.project.loginRegistration.Models.User;
import com.project.loginRegistration.Repository.UserRepository;
import com.project.loginRegistration.Service.UserService;

@Service
public class ServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepo;
		
	public User addUserDetails(@RequestBody User user) {
		return userRepo.save(user);
	}

	@Override
	public User getByemailid(String emailid) {
		return userRepo.getByemailid(emailid);
	}

	}
