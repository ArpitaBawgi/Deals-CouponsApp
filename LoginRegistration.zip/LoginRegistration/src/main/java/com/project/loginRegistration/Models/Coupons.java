package com.project.loginRegistration.Models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="couponList")
public class Coupons {

	@Id
	private long couponId;
	private String couponImage;
	private String couponDesc;
	private long couponRate;
	private String couponName;
	
	Coupons(){
	}

	public Coupons(long couponId, String couponImage, String couponDesc, long couponRate, String couponName) {
		super();
		this.couponId = couponId;
		this.couponImage = couponImage;
		this.couponDesc = couponDesc;
		this.couponRate = couponRate;
		this.couponName = couponName;
	}

	public long getCouponId() {
		return couponId;
	}

	public void setCouponId(long couponId) {
		this.couponId = couponId;
	}

	public String getCouponImage() {
		return couponImage;
	}

	public void setCouponImage(String couponImage) {
		this.couponImage = couponImage;
	}

	public String getCouponDesc() {
		return couponDesc;
	}

	public void setCouponDesc(String couponDesc) {
		this.couponDesc = couponDesc;
	}

	public long getCouponRate() {
		return couponRate;
	}

	public void setCouponRate(long couponRate) {
		this.couponRate = couponRate;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}
	
	@Override
	public String toString() {
		return "Coupons [couponId=" + couponId + ", couponImage=" + couponImage + ", couponDesc=" + couponDesc
				+ ", couponRate=" + couponRate + ", couponName=" + couponName + "]";
	}
	
}
