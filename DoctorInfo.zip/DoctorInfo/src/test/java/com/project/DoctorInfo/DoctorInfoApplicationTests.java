package com.project.DoctorInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
