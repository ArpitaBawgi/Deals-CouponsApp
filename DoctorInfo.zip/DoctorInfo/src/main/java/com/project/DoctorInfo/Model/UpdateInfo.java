package com.project.DoctorInfo.Model;

public class UpdateInfo {
	
	private String qualification;
	private long consultationfee;
	private long teleconsultfee;
	
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public long getConsultationfee() {
		return consultationfee;
	}
	public void setConsultationfee(long consultationfee) {
		this.consultationfee = consultationfee;
	}
	public long getTeleconsultfee() {
		return teleconsultfee;
	}
	public void setTeleconsultfee(long teleconsultfee) {
		this.teleconsultfee = teleconsultfee;
	}
	@Override
	public String toString() {
		return "UpdateInfo [qualification=" + qualification + ", consultationfee=" + consultationfee
				+ ", teleconsultfee=" + teleconsultfee + "]";
	}
	
    	

}
