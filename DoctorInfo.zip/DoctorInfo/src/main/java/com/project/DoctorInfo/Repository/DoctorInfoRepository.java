package com.project.DoctorInfo.Repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.project.DoctorInfo.Model.DoctorInfo;
import com.project.DoctorInfo.Model.UpdateInfo;

@Repository
public interface DoctorInfoRepository extends MongoRepository<DoctorInfo,String>{

	//public UpdateInfo updateDocInfo(UpdateInfo updateinfo );
    DoctorInfo findByName(String name);
    List<DoctorInfo> findBySpecialisation(String specialisation);
    
}
