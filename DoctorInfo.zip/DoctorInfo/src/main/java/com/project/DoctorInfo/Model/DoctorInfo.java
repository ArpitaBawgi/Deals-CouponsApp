package com.project.DoctorInfo.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="doctorinfo")
public class DoctorInfo {
	
	@Id
	private String doctorid;
	private String name;
	private String  specialisation;
	private boolean teleConsultAvailable;
	private Integer consultationfee;
	private Integer teleConsultfee;
	private String clinicAddress;
	private String qualification;
	
	DoctorInfo(){
	}

	public DoctorInfo(String doctorid,String name, String specialisation, boolean teleConsultAvailable, Integer consultationfee,
			Integer teleConsultfee, String clinicAddress, String qualification) {
		super();
		this.doctorid=doctorid;
		this.name = name;
		this.specialisation = specialisation;
		this.teleConsultAvailable = teleConsultAvailable;
		this.consultationfee = consultationfee;
		this.teleConsultfee = teleConsultfee;
		this.clinicAddress = clinicAddress;
		this.qualification= qualification;
	}

	public String getDoctorid() {
		return doctorid;
	}

	public void setDoctorid(String doctorid) {
		this.doctorid = doctorid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpecialisation() {
		return specialisation;
	}

	public void setSpecialisation(String specialisation) {
		this.specialisation = specialisation;
	}

	public boolean isTeleConsultAvailable() {
		return teleConsultAvailable;
	}

	public void setTeleConsultAvailable(boolean teleConsultAvailable) {
		this.teleConsultAvailable = teleConsultAvailable;
	}

	public Integer getConsultationfee() {
		return consultationfee;
	}

	public void setConsultationfee(Integer consultationfee) {
		this.consultationfee = consultationfee;
	}

	public Integer getTeleConsultfee() {
		return teleConsultfee;
	}

	public void setTeleConsultfee(Integer teleConsultfee) {
		this.teleConsultfee = teleConsultfee;
	}

	public String getClinicAddress() {
		return clinicAddress;
	}

	public void setClinicAddress(String clinicAddress) {
		this.clinicAddress = clinicAddress;
	}

	
	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	@Override
	public String toString() {
		return "DoctorInfo [doctorid=" + doctorid + ", name=" + name + ", specialisation=" + specialisation
				+ ", teleConsultAvailable=" + teleConsultAvailable + ", consultationfee=" + consultationfee
				+ ", teleConsultfee=" + teleConsultfee + ", clinicAddress=" + clinicAddress + ", qualification="
				+ qualification + "]";
	}
	

}
