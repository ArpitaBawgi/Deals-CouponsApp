package com.project.DoctorInfo.Service.Implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.DoctorInfo.Model.DoctorInfo;
import com.project.DoctorInfo.Repository.DoctorInfoRepository;
import com.project.DoctorInfo.Service.DoctorService;

@Service
public class DoctorInfoService implements DoctorService {
	
	@Autowired
	private DoctorInfoRepository docRepo;
	
	
	public ResponseEntity<DoctorInfo> updateDoctorInfo(String name, DoctorInfo doctorinfo){
		 DoctorInfo docinfo= docRepo.findByName(name);
		
		if(docinfo!=null) {
			docinfo.setName(docinfo.getName());
			docinfo.setTeleConsultfee(docinfo.getConsultationfee());
			docinfo.setConsultationfee(docinfo.getConsultationfee());
			docinfo.setQualification(docinfo.getQualification());
			docinfo.setClinicAddress(docinfo.getClinicAddress());
			docinfo.setTeleConsultAvailable(docinfo.isTeleConsultAvailable());
			docinfo.setSpecialisation(docinfo.getSpecialisation());
			return new ResponseEntity<>(docRepo.save(docinfo), HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}


	@Override
	public DoctorInfo addDoctor(DoctorInfo doctorInfo) {
		return docRepo.save(doctorInfo);
	}
	
	public String deleteDocById(String id) {
		 docRepo.deleteById(id);
		 return "Deleted Sucessfully";
	}



	@Override
	public DoctorInfo findByName(String name) {
		return docRepo.findByName(name);
	}


	@Override
	public List<DoctorInfo> findBySpecialisation(String specialisation) {
	   return docRepo.findBySpecialisation(specialisation);
	}
	
	public List<DoctorInfo> getAllDoctors(){
		return docRepo.findAll();
	}
	
	public Optional<DoctorInfo> findDocById(String id) {
		return docRepo.findById(id);
	}

	public DoctorInfo findDocByName(String name) {
		return docRepo.findByName(name);
	}
	
	public long findTotalCount() {
		return docRepo.count();
	}
	
//	@Override
//	public DoctorInfo findBySpeciality(String specialisation) {
//		return docRepo.findBySpeciality(specialisation);
//	}


	

}
