package com.project.DoctorInfo.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.project.DoctorInfo.Model.DoctorInfo;

@Service
public interface DoctorService {
	
	public DoctorInfo addDoctor(DoctorInfo doctorInfo);
	//public DoctorInfo findBySpeciality(String specialisation);
	public DoctorInfo findByName(String name);
	List<DoctorInfo> findBySpecialisation(String specialisation);
}
