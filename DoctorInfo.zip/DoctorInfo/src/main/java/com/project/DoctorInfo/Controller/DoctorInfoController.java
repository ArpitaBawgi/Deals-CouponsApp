package com.project.DoctorInfo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.DoctorInfo.Model.DoctorInfo;

import com.project.DoctorInfo.Service.Implementation.DoctorInfoService;

@CrossOrigin(origins="http://localhost:4200",allowedHeaders={"x-auth-token", "x-requested-with", "x-xsrf-token"})
@RestController
@RequestMapping("/docinfo")
public class DoctorInfoController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private DoctorInfoService service;
	
	
	//for admin use
//	public ResponseEntity<DoctorInfo> AddDoctor(@RequestBody DoctorInfo docInfo){
//		DoctorInfo status=docinforepo.save(docInfo);
	//}
	@PostMapping("/adddoctor")
	public DoctorInfo AddDoctor(@RequestBody DoctorInfo docInfo) {
		service.addDoctor(docInfo);
		return docInfo ;
	}
	
	@GetMapping("/alldoctors")
	public List<DoctorInfo> getAllDoctorsInfo(){
		return service.getAllDoctors();
	}
	
	@GetMapping("/docbyid/{id}")
	public Optional<DoctorInfo> getDoctorDetails(@PathVariable String id) {
		return service.findDocById(id);
	}
	
	@GetMapping("/getDocByName/{name}")
	public ResponseEntity<DoctorInfo> getDocByName(@PathVariable String name){
		System.out.println(name);
		
		DoctorInfo docfind=service.findByName(name);
		if(docfind==null) {
			return new ResponseEntity<DoctorInfo>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<DoctorInfo>(docfind,HttpStatus.FOUND);
		}
	
	@GetMapping("/getDocBySpeciality/{specialisation}")
	public ResponseEntity<List<DoctorInfo>> getDocsBySpecialisation(@PathVariable String specialisation){
		System.out.println(specialisation);
		
		List<DoctorInfo> docfind=service.findBySpecialisation(specialisation);
		if(docfind==null) {
			return new ResponseEntity<List<DoctorInfo>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<DoctorInfo>>(docfind,HttpStatus.FOUND);
	}
	
		
	@DeleteMapping("/removebyId/{id}")
//	public ResponseEntity<String> RemovedocById(@PathVariable String id){
//		String name = "deleted successfully";
//		Optional<String> opt = Optional.of(name); 
//		try{service.deleteDocById(id);
//		return new ResponseEntity<String>(HttpStatus.OK).of(opt);
//		}catch(Exception e) {
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
	public String RemoveDoc(@PathVariable String id) {
		service.deleteDocById(id);
		return "Removed Successfully!";
	}
	
	@PutMapping("/docinfoupdate/{name}")
	public ResponseEntity<DoctorInfo> updateDoctorInfo(@PathVariable(value="name") String name,
			                           @RequestBody DoctorInfo doctorinfo) throws Exception{
		           return  service.updateDoctorInfo(name, doctorinfo);
	}
	
	@GetMapping("/totalDoctorcount")
	public long totalCount() {
		return service.findTotalCount();
	}

	

	
}
