package com.project.PatientDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
