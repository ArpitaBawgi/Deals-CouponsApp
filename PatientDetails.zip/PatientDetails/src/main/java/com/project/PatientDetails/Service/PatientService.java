package com.project.PatientDetails.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.project.PatientDetails.Model.PatientData;

@Service
public interface PatientService {

	public PatientData findByEmail(String email);
	public List<PatientData> getAllPatientList();
	public Optional<PatientData> findPatientById(String id);
	public PatientData addPatientDetails(PatientData patientData);
	public ResponseEntity<PatientData> updatePatientInfo(String email, PatientData pinfo);
	public String deletePatientbyId(@PathVariable String id)
}
