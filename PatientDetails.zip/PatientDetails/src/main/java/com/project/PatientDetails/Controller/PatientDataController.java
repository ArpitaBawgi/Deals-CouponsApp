package com.project.PatientDetails.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.PatientDetails.Model.PatientData;
import com.project.PatientDetails.Repository.PatientRepository;
import com.project.PatientDetails.Service.PatientService;

@CrossOrigin("*")
@RestController
public class PatientDataController {

	@Autowired
	private PatientService pService;

	@PostMapping("/patient/savedata")
	public ResponseEntity<PatientData> SavePatientData(@RequestBody PatientData patientData) {

		PatientData newpdata = pService.addPatientDetails(patientData);
		return new ResponseEntity<PatientData>((PatientData) newpdata, HttpStatus.CREATED);
	}

	@GetMapping("/patient/findpatient/{id}")
	public Optional<PatientData> getPDataById(@PathVariable String id) {
		Optional<PatientData> p = pService.findPatientById(id);
		return p;
	}

	
//	public ResponseEntity<PatientData> GetPatientDataByEmail(@PathVariable String email){
//		PatientData patientdata=pService.findByEmail(email);
//		System.out.println(email);
//		System.out.println(patientdata);
//		
//		if(patientdata==null) {
//			System.out.println(patientdata);
//			return new ResponseEntity<PatientData>(patientdata, HttpStatus.NO_CONTENT);
//		}
//		return new ResponseEntity<PatientData>(patientdata,HttpStatus.FOUND);
//	}
//	
	@GetMapping("/patient/mypdata/{email}")
	public ResponseEntity<PatientData> getPdatabyEmail(@PathVariable String email) {
		System.out.println(email);
		PatientData p = pService.findByEmail(email);
		if (p == null) {
			System.out.println("patientdata: " + p);
			return new ResponseEntity<PatientData>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<PatientData>(p, HttpStatus.OK);
	}

	@GetMapping("/patient/allpatients")
	public ResponseEntity<List<PatientData>> getAllCustomers() {
		List<PatientData> p = new ArrayList<>();
		try {
			pService.getAllPatientList().forEach(p::add);

			if (p.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(p, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/patient/updatedata/{email}")
	public ResponseEntity<PatientData> updateDoctorInfo(@PathVariable String email, @RequestBody PatientData pinfo)
			throws Exception {
		return pService.updatePatientInfo(email, pinfo);
	}
	
	@DeleteMapping("/patient/removepatient/{email}")
	public String DeletePatient(String email) {
		pService.deletePatientbyId(email);
		return "Deleted Successfully";
	}
	
	@DeleteMapping("/patient/removebyid/{id}")
	public String DeletePatientbyId(String id) {
		pService.deletePatientbyId(id);
		return "Deleted!";
	}
}

//@GetMapping("/patient/getpdatabyage/{age}")
//public ResponseEntity<PatientData> getpdataByAge(@PathVariable Integer age){
//	PatientData p=pService.findByAge(age);
//	System.out.println(p);
//	return new ResponseEntity<PatientData>(p, HttpStatus.OK);
//}
