package com.project.PatientDetails.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


import com.project.PatientDetails.Model.PatientData;

@Repository
public interface PatientRepository extends MongoRepository<PatientData, String> {

	PatientData findByEmail(String email);
//	Optional<PatientData> findByAge(Integer age);
}
