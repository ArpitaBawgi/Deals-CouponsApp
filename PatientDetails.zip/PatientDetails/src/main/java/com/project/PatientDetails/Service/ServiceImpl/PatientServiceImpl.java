package com.project.PatientDetails.Service.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.project.PatientDetails.Model.PatientData;
import com.project.PatientDetails.Repository.PatientRepository;
import com.project.PatientDetails.Service.PatientService;

@Service
public class PatientServiceImpl implements PatientService{

	@Autowired
	private PatientRepository patientrepo;
	
	public PatientData addPatientDetails(@RequestBody PatientData pdata) {
		return patientrepo.save(pdata);
}
	
	
	public ResponseEntity<PatientData> updatePatientInfo(String email, PatientData pinfo){
		PatientData docinfo= patientrepo.findByEmail(email);
		
		if(pinfo!=null) {
			pinfo.setFullName(pinfo.getFullName());
			pinfo.setAge(pinfo.getAge());
			pinfo.setGender(pinfo.getGender());
			pinfo.setLastpresence(pinfo.isLastpresence());
			pinfo.setPresenceDetails(pinfo.getPresenceDetails());
			pinfo.setPhoneNumber(pinfo.getPhoneNumber());
			return new ResponseEntity<>(patientrepo.save(pinfo), HttpStatus.OK);
			
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
}

	public PatientData findByEmail(String email) {
		return patientrepo.findByEmail(email);
	}
	
	public Optional<PatientData> findPatientById(String id) {
		return patientrepo.findById(id);
	}
	
	public List<PatientData> getAllPatientList() {
		return patientrepo.findAll();
	}

	public void deletePatientById(String id) {
		 patientrepo.deleteById(id);
	}


	}