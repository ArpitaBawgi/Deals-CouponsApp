package com.project.offers.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="packageData")
public class PackageDetails {

	@Id
	private String packageId;
	private String name;
	private String sampleType;
	private Boolean fastingRequired;
	private Integer OriginalPrice;
	private Integer discountPrice;
	private Integer finalPrice;
	
	PackageDetails(){
	}

	public PackageDetails(String packageId, String name, String sampleType, Boolean fastingRequired,
			Integer originalPrice, Integer discountPrice, Integer finalPrice) {
		super();
		this.packageId = packageId;
		this.name = name;
		this.sampleType = sampleType;
		this.fastingRequired = fastingRequired;
		this.OriginalPrice = originalPrice;
		this.discountPrice = discountPrice;
		this.finalPrice = finalPrice;
	}

	public String getPackageId() {
		return packageId;
	}

	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSampleType() {
		return sampleType;
	}

	public void setSampleType(String sampleType) {
		this.sampleType = sampleType;
	}

	public Boolean getFastingRequired() {
		return fastingRequired;
	}

	public void setFastingRequired(Boolean fastingRequired) {
		this.fastingRequired = fastingRequired;
	}

	public Integer getOriginalPrice() {
		return OriginalPrice;
	}

	public void setOriginalPrice(Integer originalPrice) {
		OriginalPrice = originalPrice;
	}

	public Integer getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(Integer discountPrice) {
		this.discountPrice = discountPrice;
	}

	public Integer getFinalPrice() {
		return finalPrice;
	}

	public void setFinalPrice(Integer finalPrice) {
		this.finalPrice = finalPrice;
	}

	@Override
	public String toString() {
		return "PackageDetails [packageId=" + packageId + ", name=" + name + ", sampleType=" + sampleType
				+ ", fastingRequired=" + fastingRequired + ", OriginalPrice=" + OriginalPrice + ", discountPrice="
				+ discountPrice + ", finalPrice=" + finalPrice + "]";
	}
	
	
}
