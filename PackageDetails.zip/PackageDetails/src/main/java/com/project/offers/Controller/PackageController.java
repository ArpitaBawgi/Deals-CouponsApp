package com.project.offers.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.project.offers.Model.PackageDetails;

import com.project.offers.Service.ServiceImpl.PackageServiceImpl;


@CrossOrigin(origins="http://localhost:4200",allowedHeaders={"x-auth-token", "x-requested-with", "x-xsrf-token"})
@RestController
public class PackageController {
	
	@Autowired
	private PackageServiceImpl pService;
	
	@PostMapping("/package/addnewpackage")
	public PackageDetails addPackage(@RequestBody PackageDetails packageDetails) {
	pService.addnewPackage(packageDetails);
	return packageDetails;
	}
	
	@GetMapping("/package/getAllPackages")
	public List<PackageDetails> getAllPackages(){
		return pService.getAllPackageList();
	}
	
	@PutMapping("/package/updatepackageOffer")
	public ResponseEntity<PackageDetails> updatPackageInfo(@PathVariable(value="name") String packageName, @RequestBody PackageDetails packageDetails) 
	throws Exception{
		return pService.updatePackageInfo(packageName, packageDetails);
	}
	
	@GetMapping("/package/totalPackagecount")
	public long totalCount() {
		return pService.getTotalCount();
	}
	
	@GetMapping("/package/removepack/{id}")
	public String deletePackagebyId(@PathVariable String id) {
		pService.deleteByid(id);
		return "Package Deleted Successfully!";
	}
		
}
