package com.project.offers.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.offers.Model.PackageDetails;
import com.project.offers.Repository.PackageRepo;


@Service
public interface PackageService {
	
	public PackageDetails addnewPackage(PackageDetails packageDetails);
}
