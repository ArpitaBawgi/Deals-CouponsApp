package com.project.offers.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.project.offers.Model.PackageDetails;

@Repository
public interface PackageRepo extends MongoRepository<PackageDetails, String> {
	
	PackageDetails findByName(String name);
}
