package com.project.offers.Service.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.project.offers.Model.PackageDetails;
import com.project.offers.Repository.PackageRepo;
import com.project.offers.Service.PackageService;

@Service
public class PackageServiceImpl implements PackageService{

	@Autowired
	private PackageRepo packageRepo;
	
	@Override
	public PackageDetails addnewPackage(PackageDetails packageDetails) {
		return packageRepo.save(packageDetails);
	}
	
	public Optional<PackageDetails> deleteByid(String id) {
		return packageRepo.findById(id);
	}
	
	public ResponseEntity<PackageDetails> updatePackageInfo(String name, PackageDetails packageDetails){
		PackageDetails pDetails=packageRepo.findByName(name);
	
				if(pDetails!=null) {
					pDetails.setName(pDetails.getName());
					pDetails.setSampleType(pDetails.getSampleType());
					pDetails.setFastingRequired(pDetails.getFastingRequired());
					pDetails.setOriginalPrice(pDetails.getOriginalPrice());
					pDetails.setDiscountPrice(pDetails.getDiscountPrice());
					pDetails.setFinalPrice(pDetails.getFinalPrice());
					return new ResponseEntity<>(packageRepo.save(pDetails), HttpStatus.OK);
				}
	else {
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	 }
	}

	public List<PackageDetails> getAllPackageList(){
		return  packageRepo.findAll();
	}
	
	public long getTotalCount() {
		return packageRepo.count();
	}
}
